Hides the dust when building a new build piece.

# Description


`Mod made for Kyzen in the OdinPlus discord, to hide building dust. Client only, not needed on the server.`

# Author Information

### Azumatt

`DISCORD:` Azumatt#2625

`STEAM:` https://steamcommunity.com/id/azumatt/

For Questions or Comments, find me in the Odin Plus Team Discord or in mine:

[![https://i.imgur.com/XXP6HCU.png](https://i.imgur.com/XXP6HCU.png)](https://discord.gg/Pb6bVMnFb2)
<a href="https://discord.gg/pdHgy6Bsng"><img src="https://i.imgur.com/Xlcbmm9.png" href="https://discord.gg/pdHgy6Bsng" width="175" height="175"></a>
***

<details>
<summary><b>Change Log</b></summary>

## Latest listed first

| `Version` | `Changes`                                                                           |
|-----------|-------------------------------------------------------------------------------------|
| 1.0.1     | - _Fixed a bug caused by Epic Loot's Enchanting Table. (Thanks ALo for the report)_ |
| 1.0.0     | - _Initial Release_                                                                 |

</details>
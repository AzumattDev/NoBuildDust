| `Version` | `Changes`                                                                           |
|-----------|-------------------------------------------------------------------------------------|
| 1.0.5     | - _Update for Valheim 0.217.46_                                                     |
| 1.0.4     | - _Update for Valheim 0.217.22_                                                     |
| 1.0.3     | - Run the fix last, hopefully making it compatible with more mods                   |
| 1.0.2     | - _Remove the WearNTear destruction effects as well_                                |
| 1.0.1     | - _Fixed a bug caused by Epic Loot's Enchanting Table. (Thanks ALo for the report)_ |
| 1.0.0     | - _Initial Release_                                                                 |
